/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as admin from "../admin.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as auth_password from "../auth/password.js";
import type * as authUsers from "../authUsers.js";
import type * as desk from "../desk.js";
import type * as http from "../http.js";
import type * as lib from "../lib.js";
import type * as seed from "../seed.js";
import type * as seedData from "../seedData.js";
import type * as seedPdf from "../seedPdf.js";
import type * as studentAssignments from "../studentAssignments.js";
import type * as studentDashboard from "../studentDashboard.js";
import type * as studentNotes from "../studentNotes.js";
import type * as studentPortal from "../studentPortal.js";
import type * as studentProfile from "../studentProfile.js";
import type * as studentSearch from "../studentSearch.js";
import type * as teacher from "../teacher.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  admin: typeof admin;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  "auth/password": typeof auth_password;
  authUsers: typeof authUsers;
  desk: typeof desk;
  http: typeof http;
  lib: typeof lib;
  seed: typeof seed;
  seedData: typeof seedData;
  seedPdf: typeof seedPdf;
  studentAssignments: typeof studentAssignments;
  studentDashboard: typeof studentDashboard;
  studentNotes: typeof studentNotes;
  studentPortal: typeof studentPortal;
  studentProfile: typeof studentProfile;
  studentSearch: typeof studentSearch;
  teacher: typeof teacher;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
